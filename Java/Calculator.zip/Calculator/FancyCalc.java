import java.util.Scanner;
import java.io.IOException;

public class FancyCalc{
  static double Fn, Sn, Ans, n;
  static int Calc, x, z, k;
  static boolean f = true;
  static Scanner in = new Scanner(System.in);
  public static void cls()
  {
    println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  }
  public static void gcf()
  {
    int gcf = 1, trial = 1;
    
    do{
      if(Fn%trial == 0 && Sn%trial == 0){
        gcf = trial;
        trial++;
      }
      else
      {
        trial++;
      }
    }while(trial<=Fn||trial<=Sn);
    println("Your Answer is " + gcf);
  }
     public static void Add()
     {
       Ans = Fn + Sn;
       println("Your Answer is : " +Ans);
     }
     
     public static void Sub()
     {
       Ans = Fn - Sn;
       println("Your Answer is : " +Ans);
     }
     public static void Multi()
     {
       Ans = Fn * Sn;
       println("Your Answer is : " +Ans);
     }
     public static void Divide()
     {
       Ans = Fn / Sn;
       println("Your Answer is : " +Ans);
     }
     public static double sqrt() {
       n = Fn;
       double t;
       double Rt = n / 2;
       do {
         t = Rt;
         Rt = (t + (n / t)) / 2;
       } while ((t - Rt) != 0);
       println("Your Answer is : " + Rt);
       return Rt;
     }
     public static void Pow()
     {
       Ans = Math.pow(Fn, Sn);
       println("Your Answer is : " +Ans);
     }
     public static void Cont()
     {
       println("Press \"ENTER\" to continue...");
       try {
         System.in.read();
       } catch (IOException e) {
         e.printStackTrace();
       }
     }
     public static void println(Object s)
     {
       System.out.println(s);
     }
     public static void main(String args[])
     {
       for(;;){
      println("\n\n~ Welcome to FancyCalc ~");
      Cont();
      cls();
      for (Fn = 0.01;Fn == 0.01;) {
        cls();
        println("What is your first number : ");
        Fn = In.getDouble();
      }
      for (Sn = 0.01;Sn == 0.01;) {
        cls();
        println("What is your Second number : ");
        Sn = In.getDouble();
      }
      x = 1;
      while(x==1){
        
        println("Your Numbers : " + Fn + ", " + Sn);
        switch(In.getInt("Options : \nAdd(1) \nSub(2) \nMulti(3)\nDivide(4)\nSqrt(5) - Note only first number is used\nPower(6) \nGreatest Common Factor(7)\n\nWhat calculation would you like to complete : "))
        {
          case 1 : 
            Add();
            x = 0;
            break;
          case 2 : 
            Sub();
            x = 0;
            break;
          case 3 : 
            Multi();
            x = 0;
            break;
          case 4 : 
            Divide();
            x = 0;
            break;
          case 5 : 
            sqrt();
            x = 0;
            break;
          case 6 : 
            Pow();
            x = 0;
            break;
          case 7 :
            gcf();
            x = 0;
            break;
          default: 
            println("Please Input a Valid Value...");
            break;
        }
      }
    } 
     }
     }