import java.util.*;


public class Func {
  
  static int i, p, temp, number;
  static boolean f = true;
  
  
  
  
  
  
  
  //bubble sort
  //////////////////////////////////////////////////////////////////////////////
  public static void bubsort(ArrayList<Integer> arr, boolean dupli){
    try{//bubble sort
      int p = arr.size();
      i = 0;
      while(f){
        if(i==p){
          f = false;
          Func.pr("p");
        }
        else if(arr.get(i)>arr.get(i+1)){
          int temp = arr.get(i);
          arr.set(i, arr.get(i+1));
          arr.set(i+1, temp);
          i = 0;
        }
        else{
          i++;
        }
      }
    }catch(Exception e){
      Func.pr("Sorted !");
    }
    if(dupli == true){//if true gets rid of duplicates in the arraylist
      try{
        while(number<=arr.size()){
          if(arr.get(number) == arr.get(number+1)){
            arr.remove(number);
          }
          else{
            number++;
          }
        }
      }
      catch(Exception e){
      }
    }
  }
  ///////////////////////////////////////////////////////////////////////////////
  
  
  
  
  
  
  ///////////////////////////////////////////////////////////////////////////////
  //quick sort
  //this method of sorting can be exponentially faster than bubble sort as it does not have to go through the whole array on repeat.  
  //this inturn chooses a pivot, and scans right to left, and left to right.  if the code finds two numbers that are out of order, it swaps them.
  // when the right and left scanners meet at the middle, it splits them and does exactly what happened before to both halfs.
  // it does this over and over until the array is completley sorted.
  ///////////////////////////////////////////////////////////////////////////////
  public static int split(int arr[], int numToLeft, int numToRight){ // heavy lifitng sort putting the numbers on the correct side of the pivot(selected number)
    
    int pivot = arr[numToRight]; // setting the pivot to the highest part of the array
    int i = (numToLeft-1);       // setting the index i to the first position of the array
    for(int j = numToLeft; j<numToRight;j++){
      if(arr[j] <= pivot){
        i++;
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
      
    }
    
    int temp = arr[i+1];         //swapping the index and the high array 
    arr[i+1] = arr[numToRight]; 
    arr[numToRight] = temp; 
  
    return i+1;                 //returning i becasue split() needs return int value
  }
  
  public static void qsort(int arr[], int numToLeft, int numToRight){ // recursivley sorting the array by using split()
    
    if (numToLeft<numToRight){            // if the number selected to the right is lower than the left selected number, sort them.
      int part = split(arr, numToLeft, numToRight);
      qsort(arr, numToLeft, part-1);  //sorting numbers that need to be on the left of the pivot
      qsort(arr, part+1, numToRight); //sorting numbers that need to be on the right of the pivot
    }
    
  }
    
    
    public static void parr(int arr[]){   //method to print the array 
      
      int n = arr.length;
      for(int i=0; i<n; ++i){
        System.out.println(arr[i]);
      }
    }
    
  ///////////////////////////////////////////////////////////////////////////////  
    
    
    
    
    
    
 
  // printing a string
  ///////////////////////////////////////////////////////////////////////////////  
    public static void pr(String s){
      System.out.println(s);
    }
  ///////////////////////////////////////////////////////////////////////////////  
  // Printing an error message
  ///////////////////////////////////////////////////////////////////////////////  
    public static void err(String s){
      System.err.println(s);
      
      
    }
   /////////////////////////////////////////////////////////////////////////////// 
    
    
    public static void cls(){
    pr("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    
    }
   
    
    
  }
