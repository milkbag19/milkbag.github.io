import javax.swing.*;//
import javax.swing.event.*;//
import java.awt.image.*;
import java.awt.*;//
import java.awt.event.ActionListener;//
import java.awt.event.ActionEvent;//
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;



public class SoundPlayer 
{
     
     public static void println(String s){
          System.out.println(s);
     }
     static boolean f;
     
     public static void playSound(String str){
          try{
               Clip clip = AudioSystem.getClip();
               clip.open(AudioSystem.getAudioInputStream(new File(str)));
               clip.start();
          }catch(Exception e){
               println("WRONG");
          }
     }
     
     public static void main (String [] args)
     {
          JFrame frame = new JFrame("Sound Board");
          frame.setSize(800,800);
          frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          JButton[] buttons = {new JButton("Mii Theme"), new JButton("Bruh"), new JButton("Bork", new ImageIcon("Pictures//goodboy.jpg"))};
          buttons[0].setPreferredSize(new Dimension(100,100));
          frame.setLocationRelativeTo(null);
          JBox box = JBox.vbox(
                               JBox.vglue(),
                               JBox.hbox(JBox.hglue(), buttons[0], JBox.hglue()),
                               JBox.hbox(JBox.hglue(), buttons[1], JBox.hglue()),
                               JBox.hbox(JBox.hglue(), buttons[2], JBox.hglue()),
                               JBox.vglue()
                              );
          frame.add(box);
          frame.setVisible(true);
          buttons[0].addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                    playSound("Sounds\\Wii.WAV");
                    f =false;
               }
          });
          buttons[1].addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                    playSound("Sounds\\Bruh.WAV");
                    f = false;
               }
          });
          buttons[2].addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                    playSound("Sounds\\bork.WAV");
                    f = false;
               }
          });
     }
}