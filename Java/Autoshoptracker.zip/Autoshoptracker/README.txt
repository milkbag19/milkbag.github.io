Last updated : 6/17/2019

updated by : Joshua Wells

How to launch the software :
	Method 1 - Double click on the file named 
			'Inventory Software 1.0.0'.

How to update stock numbers :
	Method 1 - Click on images
			This software allows you to quickly update stock 
			of a single item by clicking on the image.  
			Simply type in the amount used(-) or 
			purchased(+)and click submit.  
	
	Method 2 - Click on File, then click on Update Stock.
			simply select a Category in the first box.
			Then select the item you wish to update stock 				for.  Same as before, simply type in the amount 			used(-) or purchased(+)and click submit.  

			Shortcut : ALT+U
	
	
How to add an item to the software : 
	Method 1 - Click on File, then click Add Item. 
			You will now see a menu with several boxes.
			You will need to give the item a Name.
			Then, you will need to give the item a Category.
			Then, You will need to give the item a stock #.
			Then, give the item an Image by clicking on 				import.  this will open a file menu.  find the 				image you would like to use, and click open.
			Finally, give the item a description. 
			Once all boxes are filled out, you may click Add 			Item.  You will now see your new item in the 				main menu.

How to remove items from the software : 
	Method 1 - Simply click on the red 'X' and the item will
			be removed.