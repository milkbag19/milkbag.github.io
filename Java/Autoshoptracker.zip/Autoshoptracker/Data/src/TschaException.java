

import java.io.File;

public class TschaException extends RuntimeException{
     
     public TschaException(String str){
          super(str);
     }
     
     public TschaException(){
     }
     
     public static final long serialVersionUID = 42L; 

}